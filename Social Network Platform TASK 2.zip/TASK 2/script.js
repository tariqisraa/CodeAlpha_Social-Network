// Post a new post
const postBtn = document.getElementById('postBtn');
const postList = document.getElementById('postList');

postBtn.addEventListener('click', () => {
    const newPostText = document.getElementById('newPost').value;
    if (newPostText.trim()) {
        const postElement = document.createElement('div');
        postElement.classList.add('post');
        postElement.innerHTML = `
            <p>${newPostText}</p>
            <button class="likeBtn">Like</button> <span class="likesCount">0</span> likes
        `;
        postList.prepend(postElement);
        document.getElementById('newPost').value = '';

        const likeBtn = postElement.querySelector('.likeBtn');
        const likesCount = postElement.querySelector('.likesCount');

        likeBtn.addEventListener('click', () => {
            let likes = parseInt(likesCount.textContent);
            likesCount.textContent = likes + 1;
        });
    }
});

// WebSockets for real-time updates
const ws = new WebSocket('ws://localhost:8080');

ws.onmessage = (event) => {
    const notification = event.data;
    const notificationList = document.getElementById('notificationList');
    const notificationElement = document.createElement('div');
    notificationElement.textContent = notification;
    notificationList.prepend(notificationElement);
};

// Send friend request
const friendRequestBtn = document.getElementById('friendRequestBtn');
friendRequestBtn.addEventListener('click', () => {
    ws.send('Friend request sent to the server');
});
